# Contents

## monika.chr
Monika's character file. Technically just a PNG.

## natsuki.chr
Natsuki's character file. Technically just a JPEG.

## sayori.chr
Sayori's character file. Technically just Sayo-nara's OGG file.

## yuri.chr
Yuri's character file. Technically just a poem in a text file.